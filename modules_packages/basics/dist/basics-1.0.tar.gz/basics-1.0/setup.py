from distutils.core import setup

setup(name = "basics", version="1.0", py_modules=['test'], packages=['history', 'operators', 'control_flow', 'data_types'])

